$(document).ready(function(){
	$('#slider').smoothDivScroll({
		autoScrollingMode:'onStart',
		autoScrollingStep: 1
	});
});