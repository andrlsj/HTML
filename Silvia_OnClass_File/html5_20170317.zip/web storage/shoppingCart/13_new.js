function doFirst(){
	
}
window.addEventListener('load', doFirst, false);
