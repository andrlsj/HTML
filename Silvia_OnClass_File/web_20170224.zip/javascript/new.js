alert('hi~');


/* false
0
'' 或 "" (空字串)
NaN (not a number)
undefined
null

if(true){
	
} */